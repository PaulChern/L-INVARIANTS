#!/usr/bin/env python
Lx=960+1
Ly=1
Lz=60+1

wcut = 1000
