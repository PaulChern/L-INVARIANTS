#!/usr/bin/env python
from mesh import *
from Aux import *
import numpy as np
from multiprocessing import Pool
import multiprocessing as mp 
from functools import partial
from numpy import linalg as LA
import matplotlib.pyplot as plt
plt.switch_backend('agg')
from matplotlib.colors import BoundaryNorm
from matplotlib.ticker import MaxNLocator
from mpl_toolkits.axes_grid1 import make_axes_locatable, axes_size
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.colors import ListedColormap

def colorbar(mappable, ax):
    fig = ax.figure
    divider = make_axes_locatable(ax)
    cax = divider.append_axes("right", size="5%", pad=0.05)
    cbar = fig.colorbar(mappable, cax=cax)
    return cbar

num_cpus = mp.cpu_count() - 1
cal_pool = Pool(num_cpus)
print("calculation pool: ",num_cpus)

eigenval_file = "eigenval.dat"
eigenvec_file = "eigenvec.dat"
mesh_file = "vars.dat"

wcut0 = 0
wcut1 = 300

f = open(eigenval_file,'r')
ValString=f.readlines()[wcut0:wcut1]
eigenval = np.array(cal_pool.map(ParseEigen, ValString))
dim = len(eigenval)
print("eigenvalues read complete")

f = open(eigenvec_file,'r')
VecString=f.readlines()[wcut0:wcut1]
eigenvec = np.array(cal_pool.map(ParseEigen, VecString))
#unorm=LA.norm(eigenvec[:,0:dim//2], axis=1)
#Pnorm=LA.norm(eigenvec[:,dim//2:], axis=1)
#np.savetxt('unorm.dat', unorm)
#np.savetxt('Pnorm.dat', Pnorm)
print("eigenvectors read complete")

f = open(mesh_file,'r')
MeshMap = []
for line_tmp in f.readlines():
    index_tmp = line_tmp.split()
    MeshMap.append([index_tmp[0], index_tmp[1], int(index_tmp[2]), int(index_tmp[3]), int(index_tmp[4])])
print("vars and mesh read complete")

SortVecFunc = partial(SortVec, MeshMap=MeshMap, Lx=Lx, Lz=Lz)
uP_list = np.array(cal_pool.map(SortVecFunc, zip(eigenval, eigenvec)))
uP = {'u':uP_list[:,0], 'P':uP_list[:,1]}
print("variables sorted complete")
fig = plt.figure(figsize=(5.69,10.27))
plt.subplots_adjust(bottom=0.1, left=0.1, right=0.8, top=0.9, wspace=0.4, hspace=0.2)
plt.subplot2grid((1, 1), (0, 0))
Phononup = uP['P']

wmin = eigenval.min()
wmax = eigenval.max()
nw = dim
W_axis = np.linspace(wmin, wmax, nw)
sigma = 0.1*(wmax - wmin)/nw
radius = 40
LossSpectrumFunc = partial(LossSpectrum, phonon=Phononup, dim=nw, sigma=sigma, Lx=Lx, Lz=Lz, radius=radius)
spectrum = np.array(cal_pool.map(LossSpectrumFunc, W_axis))
print("data of spectrum complete")

z = np.linspace(0, Lz-1, Lz-1)
x = np.linspace(0, Lx, Lx)
X, W = np.meshgrid(x, W_axis)
#Z, W = np.meshgrid(z, W_axis)

print("start 2D plotting")
ax = plt.gca()
#levels = MaxNLocator(nbins=50).tick_values(spectrum[:,:,::3].diagonal(0,1,2).min(), spectrum[:,:,::3].diagonal(0,1,2).max())
#levels = MaxNLocator(nbins=50).tick_values(spectrum[:,0,:].min(), spectrum[:,0,:].max())
print(spectrum.min(),spectrum.max())
fftmin = spectrum.min()
fftmax = spectrum.max()
#if fftmax > 80.0:
#    fftmax = 80.0
#if fftmin < -100.0:
#    fftmin = 100.0
levels = MaxNLocator(nbins=50).tick_values(fftmin, fftmax)
cmap = plt.get_cmap('rainbow')
print(spectrum.shape)
ax.set_ylabel('Frequency [THz]', fontsize='large') 
#cf = ax.contourf(Z, W, spectrum[:,:,::3].diagonal(0,1,2), levels=levels, cmap=cmap) # 110
cf = ax.contourf(X, W, spectrum, levels=levels, cmap=cmap) # x
#cf = ax.contourf(Z, W, spectrum[:,:,0], levels=levels, cmap=cmap) # z
#plt.axis('scaled')
colorbar(cf, ax)
fig.savefig("./PhononPlots/EneLossP2.pdf")
