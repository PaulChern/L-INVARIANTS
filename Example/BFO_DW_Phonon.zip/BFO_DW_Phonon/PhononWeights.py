#!/usr/bin/env python
from mesh import *
from Aux import *
from multiprocessing import Pool
import multiprocessing as mp
import numpy as np
import matplotlib.pyplot as plt
plt.switch_backend('agg')
from matplotlib.colors import BoundaryNorm
from matplotlib.ticker import MaxNLocator
from mpl_toolkits.axes_grid1 import make_axes_locatable, axes_size
num_cpus = mp.cpu_count() - 1
cal_pool = Pool(num_cpus)

def colorbar(mappable, ax):
    fig = ax.figure
    divider = make_axes_locatable(ax)
    cax = divider.append_axes("right", size="5%", pad=0.05)
    cbar = fig.colorbar(mappable, cax=cax)
    cbar.ax.tick_params(labelsize=6)
    return cbar

eigenval_file = "eigenval.dat"
eigenvec_file = "eigenvec.dat"
mesh_file = "vars.dat"

wcut0 = 0
wcut1 = 1000

f = open(eigenval_file,'r')
ValString=f.readlines()[wcut0:wcut1]
eigenval = np.array(cal_pool.map(ParseEigen, ValString))
dim = len(eigenval)
print("eigenvalues read complete")

f = open(eigenvec_file,'r')
VecString=f.readlines()[wcut0:wcut1]
eigenvec = np.array(cal_pool.map(ParseEigen, VecString))
print("eigenvectors read complete")

f = open(mesh_file,'r')
MeshMap = []
for line_tmp in f.readlines():
    index_tmp = line_tmp.split()
    MeshMap.append([index_tmp[0], index_tmp[1], int(index_tmp[2]), int(index_tmp[3]), int(index_tmp[4])])

uP = {'u':[],'P':[]}
for i, w in enumerate(eigenval):
    Pi = {'1':np.zeros((Lz,1,Lx)), '2':np.zeros((Lz,1,Lx)), '3':np.zeros((Lz,1,Lx)),'w':w, 'i':i}
    ui = {'1':np.zeros((Lz,1,Lx)), '2':np.zeros((Lz,1,Lx)), '3':np.zeros((Lz,1,Lx)),'w':w, 'i':i}
    for j, m in enumerate(MeshMap):
        if m[0]=='P':
            Pi[m[1]][m[4]-1, m[3]-1, m[2]-1] = eigenvec[i][j]
        if m[0]=='u':
            ui[m[1]][m[4]-1, m[3]-1, m[2]-1] = eigenvec[i][j]
    uP['u'].append(ui)
    uP['P'].append(Pi)

for iphonon in range(wcut1-wcut0):
    print("plotting phonon "+str(iphonon))
#    print("plotting phonon "+str(iphonon))
    for iup in range(6):
        if iup < 3:
            mode = 'P'
            modei = str(iup+1) 
            pdata = uP[mode][iphonon][modei][:,0,:]
            pnorm = np.linalg.norm(pdata)
            pmin = pdata.min()
            pmax = pdata.max()
        else:
            mode = 'u'
            modei = str(iup-3+1) 
            pdata = uP[mode][iphonon][modei][:,0,:]
            pnorm = np.linalg.norm(pdata)
            pmin = pdata.min()
            pmax = pdata.max()
        if mode=='P' and modei=='2' and pnorm**2 >0.09:
            print(mode+str(modei), ": ", pnorm**2, "\t", pmin, "\t", pmax), "dw"
        else:
            print(mode+str(modei), ": ", pnorm**2, "\t", pmin, "\t", pmax)
    print("\n")
