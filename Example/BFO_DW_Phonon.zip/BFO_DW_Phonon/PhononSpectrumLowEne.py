#!/usr/bin/env python
from mesh import *
from Aux import *
import numpy as np
from multiprocessing import Pool
import multiprocessing as mp 
from functools import partial
from numpy import linalg as LA
import matplotlib.pyplot as plt
from matplotlib.colors import BoundaryNorm
from matplotlib.ticker import MaxNLocator
from mpl_toolkits.axes_grid1 import make_axes_locatable, axes_size
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.colors import ListedColormap

num_cpus = mp.cpu_count() - 1
cal_pool = Pool(num_cpus)

eigenval_file = "eigenval.dat"
eigenvec_file = "eigenvec.dat"
mesh_file = "vars.dat"

wcut = 3000

f = open(eigenval_file,'r')
ValString=f.readlines()[0:wcut]
eigenval = np.array(cal_pool.map(ParseEigen, ValString))
dim = len(eigenval)
print("eigenvalues read complete")

f = open(eigenvec_file,'r')
VecString=f.readlines()[0:wcut]
eigenvec = np.array(cal_pool.map(ParseEigen, VecString))
#unorm=LA.norm(eigenvec[:,0:dim//2], axis=1)
#Pnorm=LA.norm(eigenvec[:,dim//2:], axis=1)
#np.savetxt('unorm.dat', unorm)
#np.savetxt('Pnorm.dat', Pnorm)
print("eigenvectors read complete")

f = open(mesh_file,'r')
MeshMap = []
for line_tmp in f.readlines():
    index_tmp = line_tmp.split()
    MeshMap.append([index_tmp[0], index_tmp[1], int(index_tmp[2]), int(index_tmp[3]), int(index_tmp[4])])
print("vars and mesh read complete")

SortVecFunc = partial(SortVec, MeshMap=MeshMap, Lx=Lx, Lz=Lz)
uP_list = np.array(cal_pool.map(SortVecFunc, zip(eigenval, eigenvec)))
uP = {'u':uP_list[:,0], 'P':uP_list[:,1]}
print("variables sorted complete")
fig = plt.figure(figsize=(15.69,5.27))
plt.subplots_adjust(bottom=0.1, left=0.02, right=0.9, top=0.9, wspace=0.4, hspace=0.2)
modeup = ['P','u']
#for mode in modeup:
for iup in range(6):
    print(modeup[iup//3], str(iup%3+1))
    plt.subplot2grid((2, 3), (iup//3, iup%3))
    Phononup = uP[modeup[iup//3]]

    LandauFFTFunc = partial(LandauFFT, Lx=Lx, Lz=Lz, xyz=str(iup%3+1))
    phonon_data = cal_pool.map(LandauFFTFunc, Phononup)
    print("fft complete")
    
    wmin = eigenval.min()
    wmax = eigenval.max()
    nw = dim
    W_axis = np.linspace(wmin, wmax, nw)
    sigma = 1*(wmax - wmin)/nw
    
    RenderSpectrumFunc = partial(RenderSpectrum, phonon=phonon_data, dim=nw, sigma=sigma, Lx=Lx, Lz=Lz)
    spectrum = np.array(cal_pool.map(RenderSpectrumFunc, W_axis))
    print("data of spectrum complete")
    
    z = np.linspace(0, (Lz-1)//2-1, (Lz-1)//2-1)
    x = np.linspace(0, (Lx-1)//2, (Lx-1)//2)
    X, W = np.meshgrid(x, W_axis)
    Z, W = np.meshgrid(z, W_axis)
    
    print("start 2D plotting")
    ax = plt.gca()
    levels = MaxNLocator(nbins=50).tick_values(spectrum[:,:,::3].diagonal(0,1,2).min(), spectrum[:,:,::3].diagonal(0,1,2).max())
#    levels = MaxNLocator(nbins=50).tick_values(spectrum[:,0,:].min(), spectrum[:,0,:].max())
    fftmin = spectrum[:,:,0].min()
    fftmax = spectrum[:,:,0].max()
    if fftmax > 30000.0:
        fftmax = 30000.0
    levels = MaxNLocator(nbins=50).tick_values(fftmin, fftmax)
    cmap = plt.get_cmap('rainbow')
    print(spectrum.shape)
    cf = ax.contourf(Z, W, spectrum[:,:,::3].diagonal(0,1,2), levels=levels, cmap=cmap) # 110
    #cf = ax.contourf(X, W, spectrum[:,0,:], levels=levels, cmap=cmap) # x
    #cf = ax.contourf(Z, W, spectrum[:,:,0], levels=levels, cmap=cmap) # z
    #plt.axis('scaled')
    colorbar(cf, ax)
#ax.set_title('PhononSpectrum')
fig.savefig("./PhononPlots/Spectrum2D.pdf")
#plt.show()

#    print("start 3D plotting")
#    X, Z = np.meshgrid(x, z)
#
#    fig = plt.figure()
#    ax = plt.axes(projection='3d')
#    levels = MaxNLocator(nbins=50).tick_values(spectrum.min(), spectrum.max())
#    cmap = plt.get_cmap('rainbow')
#    my_cmap = cmap(np.arange(cmap.N))
#    my_cmap[:,-1] = np.linspace(0, 1, cmap.N)
#    my_cmap = ListedColormap(my_cmap)
#    for w, fft in zip(W_axis, spectrum):
#        ax.contourf(X, Z, fft, zdir='z', cmap=my_cmap, levels=levels, offset=w, antialiased=True)
#        ax.set_zlim(eigenval.min(), eigenval.max())
#    fig.savefig("./PhononPlots/Spectrum3D"+mode+".pdf")
    #plt.show()

