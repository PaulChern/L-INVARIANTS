#!/usr/bin/env python
import os.path
from fenics import *
from dolfin import *
from mshr import *
import scipy.sparse as sp
from scipy.sparse.linalg  import eigsh
import numpy as np
import sympy as sym
from FenicsLandau import LandauGinzburg, NewtonInfo

class PeriodicBoundaryY(SubDomain):

    def inside(self, x, on_boundary):
        return bool(near(x[1], -Ny*pixel, tol) and on_boundary)

    def map(self, x, y):
        y[0] = x[0]
        y[1] = x[1] - 2*Ny*pixel
        y[2] = x[2]

def boundary_L(x, on_boundary):
    return on_boundary and near(x[0], -Nx*pixel, tol)
def boundary_R(x, on_boundary):
    return on_boundary and near(x[0], Nx*pixel, tol)
def boundary_B(x, on_boundary):
    return on_boundary and near(x[2], -Nz*pixel, tol)

'''
##############
# Parameters #
##############
'''
comm = MPI.comm_world
Nx = 90; Ny = 1; Nz = 30; pixel = 10E-10
P0 = 0.48
tol = 1E-20
m_O = 15.999; m_Fe = 55.845; m_Bi = 208.98; m_std = 1.6606E-27
m_tot = m_Fe + m_Bi + 3*m_O
volume_BFO = 488.87*1.0E-30/8
rho = m_tot*m_std/volume_BFO
'''
##################
# Function space #
##################
'''
mesh = BoxMesh(Point(-Nx*pixel, -Ny*pixel, -Nz*pixel), Point(Nx*pixel, Ny*pixel, Nz*pixel), 2*Nx, 2*Ny, 2*Nz)
elements = VectorElement('Lagrange', tetrahedron, 2, dim=3)
V = FunctionSpace(mesh, MixedElement([elements, elements]), constrained_domain=PeriodicBoundaryY())

v = TestFunction(V)
vu, vp = split(v)

if os.path.isfile("./FenicsOutputs/saved_up.xml"):
    up0 = Function(V, "./FenicsOutputs/saved_up.xml")
else:
    up0 = interpolate(Expression(("0", "0", "0", "P0", "P0*tanh((x[0]+x[2])/5.0E-10)", "P0"), P0=0.48, degree=2), V)

u0, p0 = split(up0)

'''
#######################
# Boundary conditions #
#######################
'''
bc_L = DirichletBC(V.sub(1), Constant((-P0, -P0, P0)), boundary_L)
bc_R = DirichletBC(V.sub(1), Constant((-P0, P0, P0)), boundary_R)
bc_B = DirichletBC(V.sub(0), Constant((0, 0, 0)), boundary_B)

bcs = []

'''
#################################
# Get Hessian, Gradiant and Mass#
#################################
'''
up = Function(V)
u, p = split(up)
w = TrialFunction(V)
Model = LandauGinzburg(u=u, p=p, r=None)
F = Model.get_LagrangianrUP()

dF = derivative(F*dx, up, TestFunction(V))
H = derivative(dF, up, TrialFunction(V))

m = rho*inner(v,w)*dx

'''
#################
# Newton Solver #
#################
'''
if MPI.rank(comm) == 0:
    print("start Newton solver:")
#solver = KrylovSolver("cg", "ilu") 
#solver.parameters["absolute_tolerance"] = 1E-7 
#solver.parameters["relative_tolerance"] = 1E-4 
#solver.parameters["maximum_iterations"] = 1000 
#set_log_level(DEBUG)
#solver.solve(K, up.vector(), b)
dup = Function(V)
up_tmp = Function(V)
u0, p0 = split(up0)
mix=1.0; tol=1.0E-14; maxiter=6
eps = 1.0; jter = 0
up_tmp.vector()[:] = up0.vector()
u0, p0 = up_tmp.split()
vtkfile_u_tmp = File('./FenicsOutputs/tmp/u_iter.pvd')
vtkfile_p_tmp = File('./FenicsOutputs/tmp/p_iter.pvd')
vtkfile_u_tmp << (u0, float(jter))
vtkfile_p_tmp << (p0, float(jter))
while eps > tol and jter < maxiter:
    jter += 1
    K, b = assemble_system(replace(H, {up: up0}), replace(dF, {up: up0}), bcs)

    solve(K, dup.vector(), b)

#    eps = norm(dup.vector().get_local(), 'linf')
    eps = np.linalg.norm(dup.vector().get_local(), ord=np.Inf)

    if eps < 1.0E-4:
        mix = 0.0001

    if MPI.rank(comm) == 0:
        NewtonInfo(jter,eps)
        print("Newton "+str(jter)+":", eps)

    up_tmp.vector()[:] = up0.vector() - mix*dup.vector()
    up0.assign(up_tmp)

    u, p = up_tmp.split()
    vtkfile_u_tmp << (u, float(jter))
    vtkfile_p_tmp << (p, float(jter))

if MPI.rank(comm) == 0:
    print("end Newton solver.")

'''
#################
# Phonon solver #
#################
'''
if MPI.rank(comm) == 0:
    print("start phonon solver:")

K = PETScMatrix()
M = PETScMatrix()
b = PETScVector()
assemble_system(m, replace(dF, {up: up0}), bcs, A_tensor=M, b_tensor=b)
assemble_system(replace(H, {up: up0}), replace(dF, {up: up0}), bcs, A_tensor=K, b_tensor=b)

eigensolver = SLEPcEigenSolver(K, M)
#info(eigensolver, True)
eigensolver.parameters["solver"] = "krylov-schur"
#eigensolver.parameters["solver"] = "arnoldi"
#eigensolver.parameters['spectrum'] = 'target real'
eigensolver.parameters['spectrum'] = 'largest magnitude'
#eigensolver.parameters["spectral_transform"] = "shift-and-invert"
#eigensolver.parameters["spectral_shift"] = 1.0E-30
eigensolver.parameters['tolerance'] = 1.e-30
eigensolver.parameters['problem_type'] = 'gen_hermitian'
#eigensolver.parameters['maximum_iterations'] = 1000000000000000
#eigensolver.parameters['verbose'] = True # for debugging
#print(eigensolver.parameters.str(True))
#PETScOptions.set("eps_view")
#comm.Bcast(eigensolver, root)

Nomega = 1000
eigensolver.solve(Nomega)
converged = eigensolver.get_number_converged()
if MPI.rank(comm) == 0:
#    print("Total number of iterations: %r" % eigensolver.get_iteration_number())
    print("Converged: %r" % converged)
    print("end phonon solver.")

'''
##########
# output #
##########
'''
File('./FenicsOutputs/saved_up.xml') << up_tmp
## Save solution to file in VTK format
#File('./saved_mesh.xml') << mesh
File('./FenicsOutputs/u.pvd') << u
File('./FenicsOutputs/p.pvd') << p

eigenmode = Function(V)
vtkphononu = File('./FenicsOutputs/phonon_u.pvd')
vtkphononp = File('./FenicsOutputs/phonon_p.pvd')
for iomega in range(converged):
    r, c, rx, cx = eigensolver.get_eigenpair(iomega)

    omega = np.sqrt(r)/2/np.pi
    eps = norm(rx, 'l2', mesh)

    if MPI.rank(comm) == 0:
        print('Eigenvalue' + str(iomega) + ' ' + str(omega) + ' + i * ' + str(c) + ' omega2: ' + str(r))

    eigenmode.vector()[:] = rx/eps

    (phononur, phononpr) = eigenmode.split()

    vtkphononu << (phononur, float(iomega))
    vtkphononp << (phononpr, float(iomega))
    File('./FenicsOutputs/phonon-'+str(iomega)+'.xml') << eigenmode
