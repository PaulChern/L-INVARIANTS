#!/usr/bin/env python
import os.path
from fenics import *
from dolfin import *
from mshr import *
import scipy.sparse as sp
from scipy.sparse.linalg  import eigsh
import numpy as np
import sympy as sym
from FenicsLandau import LandauGinzburg

class PeriodicBoundaryY(SubDomain):

    def inside(self, x, on_boundary):
        return bool(near(x[1], -Ny*pixel, tol) and on_boundary)

    def map(self, x, y):
        y[0] = x[0]
        y[1] = x[1] - 2*Ny*pixel
        y[2] = x[2]

def boundary_L(x, on_boundary):
    return on_boundary and near(x[0], -Nx*pixel, tol)
def boundary_R(x, on_boundary):
    return on_boundary and near(x[0], Nx*pixel, tol)
def boundary_B(x, on_boundary):
    return on_boundary and near(x[2], -Nz*pixel, tol)

'''
##############
# Parameters #
##############
'''

Nx = 90; Ny = 1; Nz = 30; pixel = 10E-10
P0 = 0.48
tol = 1E-20
m_O = 15.999; m_Fe = 55.845; m_Bi = 208.98; m_std = 1.6606E-27
m_tot = m_Fe + m_Bi + 3*m_O
volume_BFO = 488.87*1.0E-30/8
rho = m_tot*m_std/volume_BFO
'''
##################
# Function space #
##################
'''
mesh = BoxMesh(Point(-Nx*pixel, -Ny*pixel, -Nz*pixel), Point(Nx*pixel, Ny*pixel, Nz*pixel), 2*Nx, 2*Ny, 2*Nz)
elements = VectorElement('Lagrange', tetrahedron, 2, dim=3)
V = FunctionSpace(mesh, MixedElement([elements, elements]), constrained_domain=PeriodicBoundaryY())

v = TestFunction(V)
vu, vp = split(v)

if os.path.isfile("./saved_up.xml"):
    up0 = Function(V, "./saved_up.xml")
else:
    up0 = interpolate(Expression(("0", "0", "0", "P0", "P0*tanh((x[0]+x[2])/10.0E-10)", "P0"), P0=0.48, degree=2), V)

u0, p0 = split(up0)

'''
#######################
# Boundary conditions #
#######################
'''
bc_L = DirichletBC(V.sub(1), Constant((-P0, -P0, P0)), boundary_L)
bc_R = DirichletBC(V.sub(1), Constant((-P0, P0, P0)), boundary_R)
bc_B = DirichletBC(V.sub(0), Constant((0, 0, 0)), boundary_B)

bcs = []

'''
###################
# Assemble system #
###################
'''
up = Function(V)
u, p = split(up)
Model = LandauGinzburg(u=u, p=p, r=None)
F = Model.get_LagrangianUP()

dF = derivative(F*dx, up, TestFunction(V))
H = derivative(dF, up, TrialFunction(V))

K = PETScMatrix()
b = PETScVector()
assemble_system(replace(H, {up: up0}), replace(dF, {up: up0}), bcs, A_tensor=K, b_tensor=b)

print("start linear system:")
solver = KrylovSolver("cg", "ilu") 
solver.parameters["absolute_tolerance"] = 1E-7 
solver.parameters["relative_tolerance"] = 1E-4 
solver.parameters["maximum_iterations"] = 1000 
set_log_level(DEBUG)
solver.solve(K, up.vector(), b)
print("end linear system.")
#print(b.get_local()[-100:])
#cell_iter = cells(mesh)
# local stiffness assembly function
#def kte_calc(tp_cell_e):
#    return assemble_local(H, tp_cell_e[1])

# list of local stiffness matrix
#list_Kt_e = map(kte_calc, enumerate(cell_iter))
#print(list(list_Kt_e)[0])

M = PETScMatrix()
m = rho*inner(v,w)*dx
#m = rho*inner(vu,wu)*dx + (m_Bi/m_tot)*rho*inner(vp,wp)*dx
assemble_system(m, replace(dF, {up: up0}), bcs, A_tensor=M, b_tensor=b)
#print(M.is_symmetric(1E-15))
#Marray=as_backend_type(M).mat().getValuesCSR()[2]
#print(Marray)
#print(Marray.sum())
#print(Marray.min())
#print(Marray.max())

#Ksci = sp.csr_matrix(as_backend_type(K).mat().getValuesCSR()[::-1], dtype=np.float)
#Msci = sp.csr_matrix(as_backend_type(M).mat().getValuesCSR()[::-1], dtype=np.float)

#jj = Function(V)
#dofmap = V.dofmap() 
#for cell in cells(mesh):                                                       
#    jj.vector()[dofmap.cell_dofs(cell.index())] = cell.volume()                   
#
#min_ = jj.vector().min()                                                        
#max_ = jj.vector().max()
#print("cell volume: ", min_, max_)

'''
##########
# Solver #
##########
'''
eigensolver = SLEPcEigenSolver(K, M)
#info(eigensolver, True)
eigensolver.parameters["solver"] = "krylov-schur"
#eigensolver.parameters["solver"] = "arnoldi"
eigensolver.parameters['spectrum'] = 'target real'
eigensolver.parameters["spectral_transform"] = "shift-and-invert"
eigensolver.parameters["spectral_shift"] = 1.0E-30
eigensolver.parameters['tolerance'] = 1.e-30
eigensolver.parameters['problem_type'] = 'gen_hermitian'
#eigensolver.parameters['maximum_iterations'] = 1000000000000000
#eigensolver.parameters['verbose'] = True # for debugging
#print(eigensolver.parameters.str(True))
PETScOptions.set("eps_view")

Nomega = 10
eigensolver.solve(Nomega)
converged = eigensolver.get_number_converged()
print("Total number of iterations: %r" % eigensolver.get_iteration_number())
print("Converged: %r" % converged)

#print("scipy solver")
#w, wv = eigsh(Ksci, k=100, which="SM")
#print(w, wv)
'''
##########
# output #
##########
'''
for iomega in range(converged):
    r, c, rx, cx = eigensolver.get_eigenpair(i=iomega)
    omega = np.sqrt(r)/2/np.pi
    print('Eigenvalue' + str(iomega) + ' ' + str(omega) + ' + i * ' + str(c) + ' omega2: ' + str(r))

    eigenmode = Function(V, name="Eigenvector"+str(iomega))
    eigenmode.vector()[:] = rx
    phononur, phononpr = eigenmode.split()
    
    vtkfilephononur = File('./phonon/ur'+str(iomega)+'.pvd')
    vtkfilephononpr = File('./phonon/pr'+str(iomega)+'.pvd')
    vtkfilephononur << phononur
    vtkfilephononpr << phononpr
    
#    wi = Function(V)
#    wi.vector()[:] = cx
#    phononui, phononpi = wi.split()
#
#    vtkfilephononui = File('./phonon/ui'+str(iomega)+'.pvd')
#    vtkfilephononpi = File('./phonon/pi'+str(iomega)+'.pvd')
#    vtkfilephononui << phononui
#    vtkfilephononpi << phononpi
