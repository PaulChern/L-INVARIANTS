#!/usr/bin/env python
import os.path
from fenics import *
from dolfin import *
from mshr import *
from scipy import linalg, matrix, sparse
import sympy as sym
from LandauLagrangian import weakUP, LagrangianUP

def boundary_L(x, on_boundary):
    return on_boundary and near(x[0], -Nx*pixel, tol)
def boundary_R(x, on_boundary):
    return on_boundary and near(x[0], Nx*pixel, tol)
def boundary_B(x, on_boundary):
    return on_boundary and near(x[2], -Nz*pixel, tol)

class PeriodicBoundaryY(SubDomain):

    def inside(self, x, on_boundary):
        return bool(near(x[1], -Ny*pixel, tol) and on_boundary)

    def map(self, x, y):
        y[0] = x[0]
        y[1] = x[1] - 2*Ny*pixel
        y[2] = x[2]

'''
##############
# Parameters #
##############
'''
Nx = 90; Ny = 1; Nz = 30; pixel = 10E-10
P0 = 0.48
tol = 1E-20

'''
##################
# Function space #
##################
'''
mesh = BoxMesh(Point(-Nx*pixel, -Ny*pixel, -Nz*pixel), Point(Nx*pixel, Ny*pixel, Nz*pixel), 2*Nx, 2*Ny, 2*Nz)
elements = VectorElement('Lagrange', tetrahedron, 2, dim=3)
V = FunctionSpace(mesh, MixedElement([elements, elements]), constrained_domain=PeriodicBoundaryY())

#print(mesh.cells())
#print(mesh.geometry())
#print(mesh.geometry().dim())
dup = TrialFunction(V)
v = TestFunction(V)
vu, vp = split(v)
if os.path.isfile("./saved_up.xml"):
    up = Function(V, "./saved_up.xml")
else:
    up = interpolate(Expression(("0", "0", "0", "P0", "P0*tanh((x[0]+x[2])/10.0E-10)", "P0"), P0=0.48, degree=2), V)

u, p = split(up)

'''
#######################
# Boundary conditions #
#######################
'''
bc_L = DirichletBC(V.sub(1), Constant((-P0, -P0, P0)), boundary_L)
bc_R = DirichletBC(V.sub(1), Constant((-P0, P0, P0)), boundary_R)
bc_B = DirichletBC(V.sub(0), Constant((0, 0, 0)), boundary_B)

bcs = []

'''
###################
# Assemble system #
###################
'''
#F = weakUP(vu=vu, vp=vp, u=u, p=p)
F = LagrangianUP(u=u, p=p)
dF = derivative(F*dx, up, v)
J = derivative(dF, up)

'''
##########
# Solver #
##########
'''
problem = NonlinearVariationalProblem(dF, up, bcs, J)

solver  = NonlinearVariationalSolver(problem)
prm = solver.parameters
#prm['newton_solver']['linear_solver'] = "gmres"
#prm['newton_solver']['preconditioner'] = "ilu"
prm['newton_solver']['absolute_tolerance'] = 1E-20
prm['newton_solver']['relative_tolerance'] = 1.0E-20
prm['newton_solver']['maximum_iterations'] = 100
prm['newton_solver']['relaxation_parameter'] = 1.0
prm['newton_solver']["error_on_nonconvergence"] = False
prm['newton_solver']["report"] = True
prm["symmetric"] = True
#info(parameters, True)
#info(prm, True)
#set_log_level(PROGRESS)
solver.solve()

'''
##########
# output #
##########
'''
File('./saved_up.xml') << up
## Save solution to file in VTK format
#File('./saved_mesh.xml') << mesh
vtkfileu = File('./Landau/u.pvd')
vtkfilep = File('./Landau/p.pvd')
vtkfileu << u
vtkfilep << p
#print(p.compute_vertex_values(mesh))
#print(u.compute_vertex_values(mesh))

u_nodal_values = u.compute_vertex_values(mesh)
u_array = u_nodal_values
coor = mesh.coordinates()
#if mesh.num_vertices() == len(u_array):
#    for i in range(mesh.num_vertices()):
#        print('u(%8g,%8g) = %g' % (coor[i][0], coor[i][1], coor[i][2], u_array[i]))
