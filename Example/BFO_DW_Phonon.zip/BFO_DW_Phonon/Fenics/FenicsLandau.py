#!/usr/bin/env python
from fenics import *
from dolfin import *
from mshr import *
import sympy as sym
import numpy as np
from decimal import Decimal

a1 = 8.78E5*(300 - 830)
a11 = 4.71E8; a12 = 5.74E8
a111 = 0.0; a112 = 0.0; a123 = 0.0

G1111 = 0.6*0.98*1E-10; G1122 = 0.0; G1212 = 0.6*0.98*1E-10
Q1111 = 0.035; Q1122 = -0.0175; Q1212 = 0.02015
F1111 = 0.0; F1122 = 0.0; F1212 = 0.0
C1111 = 3.02E11; C1122 = 1.62E11; C1212 = 0.68E11

pixel = 10E-10

q1111 = 2*C1111*Q1111 + 4*C1122*Q1122
q1122 = 2*C1122*Q1111 + 2*C1111*Q1122 + 2*C1122*Q1122
q1212 = 2*C1212*Q1212
Ex = 0; Ey = 0; Ez = 0
Edx = 0; Edy = 0; Edz = 0
#f1111 = 2*C1111*F1111 + 4*C1122*F1122
#f1122 = 2*C1122*F1111 + 2*C1111*F1122 + 2*C1122*F1122
#f1212 = 2*C1212*F1212
f1111 = 2.5
f1122 = 2.5
f1212 = -0.5

ai = as_vector([a1, a1, a1])
E = as_vector([Ex, Ey, Ez])
Ed = as_vector([Edx, Edy, Edz])

aij = as_tensor([[2.0*a11,     a12,     a12],
                 [    a12, 2.0*a11,     a12],
                 [    a12,     a12, 2.0*a11]])

aijk = as_tensor([[[2.0*a111,     2.0/3.0*a112, 2.0/3.0*a112],
                   [2.0/3.0*a112, 2.0/3.0*a112, 1.0/3.0*a123],
                   [2.0/3.0*a112, 1.0/3.0*a123, 2.0/3.0*a112]],
                  [[2.0/3.0*a112, 2.0/3.0*a112, 1.0/3.0*a123],
                   [2.0/3.0*a112, 2.0*a111,     2.0/3.0*a112],
                   [1.0/3.0*a123, 2.0/3.0*a112, 2.0/3.0*a112]],
                  [[2.0/3.0*a112, 1.0/3.0*a123, 2.0/3.0*a112],
                   [1.0/3.0*a123, 2.0/3.0*a112, 2.0/3.0*a112],
                   [2.0/3.0*a112, 2.0/3.0*a112, 2.0*a111    ]]])

def T4th(v1111, v1122, v1212):
    return as_tensor([[[[v1111, 0.0, 0.0], [0.0, v1122, 0.0], [0.0, 0.0, v1122]],
                       [[0.0, v1212, 0.0], [0.0, 0.0, 0.0],     [0.0, 0.0, 0.0]],
                       [[0.0, 0.0, v1212], [0.0, 0.0, 0.0],     [0.0, 0.0, 0.0]]],
                      [[[0.0, 0.0, 0.0],     [v1212, 0.0, 0.0], [0.0, 0.0, 0.0]],
                       [[v1122, 0.0, 0.0], [0.0, v1111, 0.0], [0.0, 0.0, v1122]],
                       [[0.0, 0.0, 0.0],     [0.0, 0.0, v1212], [0.0, 0.0, 0.0]]],
                      [[[0.0, 0.0, 0.0],     [0.0, 0.0, 0.0],     [v1212, 0.0, 0.0]],
                       [[0.0, 0.0, 0.0],     [0.0, 0.0, 0.0],     [0.0, v1212, 0.0]],
                       [[v1122, 0.0, 0.0], [0.0, v1122, 0.0], [0.0, 0.0, v1111]]]])

Gijkl = T4th(G1111, G1122, G1212)
Cijkl = T4th(C1111, C1122, C1212)
Qijkl = T4th(Q1111, Q1122, Q1212)
qijkl = T4th(q1111, q1122, q1212)
Fijkl = T4th(F1111, F1122, F1212)
fijkl = T4th(f1111, f1122, f1212)

i, j, k, l = indices(4)

class LandauGinzburg(object):
    """
    GinzburgLandau model for ferroelectric material

    Attributes:
        u : displacement vector [ux, uy, uz]
        p : polarization vector [px, py, pz]
        r : ochahedral rotation vector [rx, ry, rz]
    """

    def __init__(self, u, p, r=None):

        self.displacement = u
        self.polarization = p
        self.rotation = r
        self.Landau = self._set_Landau()
        self.Ginzburg = self._set_Ginzburg()
        self.Elastic = self._set_Elastic()
        self.Electrostriction = self._set_Electrostriction()
        self.Flexoelectric  = None

    def _set_Landau(self):
        u = self.displacement
        p = self.polarization
        r = self.rotation
        F = ai[0]*p[0]**2 + ai[1]*p[1]**2 + ai[2]*p[2]**2 + \
            0.5*aij[0,0]*p[0]**2*p[0]**2 + 0.5*aij[0,1]*p[0]**2*p[1]**2 + 0.5*aij[0,2]*p[0]**2*p[2]**2 + \
            0.5*aij[1,0]*p[1]**2*p[0]**2 + 0.5*aij[1,1]*p[1]**2*p[1]**2 + 0.5*aij[1,2]*p[1]**2*p[2]**2 + \
            0.5*aij[2,0]*p[2]**2*p[0]**2 + 0.5*aij[2,1]*p[2]**2*p[1]**2 + 0.5*aij[2,2]*p[2]**2*p[2]**2 
        return(F)

    def _set_Ginzburg(self):
        u = self.displacement
        p = self.polarization
        r = self.rotation
        F = 0.5*Gijkl[i,j,k,l]*p[i].dx(j)*p[k].dx(l)
        return(F)

    def _set_Elastic(self):
        u = self.displacement
        p = self.polarization
        r = self.rotation
        F = 0.125*Cijkl[i,j,k,l]*u[i].dx(j)*u[k].dx(l) + \
            0.125*Cijkl[i,j,k,l]*u[i].dx(j)*u[l].dx(k) + \
            0.125*Cijkl[i,j,k,l]*u[j].dx(i)*u[k].dx(l) + \
            0.125*Cijkl[i,j,k,l]*u[j].dx(i)*u[l].dx(k)
        return(F)

    def _set_Electrostriction(self):
        u = self.displacement
        p = self.polarization
        r = self.rotation
        F = 0.25*qijkl[i,j,k,l]*u[i].dx(j)*p[k]*p[l] - 0.25*qijkl[i,j,k,l]*u[j].dx(i)*p[k]*p[l]
        return(F)

    def get_weakUP(self, vu, vp):
        u = self.displacement
        p = self.polarization
        r = self.rotation
        F = (2*Cijkl[0,k,0,l]*grad(u[0])[l]*grad(vu[0])[k] + 2*Cijkl[0,k,l,0]*grad(u[0])[l]*grad(vu[0])[k] \
             - qijkl[0,k,0,l]*p[l]*grad(vu[0])[k]*p[0] - qijkl[0,k,l,0]*p[l]*grad(vu[0])[k]*p[0] + \
            2*Cijkl[0,k,1,l]*grad(u[1])[l]*grad(vu[0])[k] + 2*Cijkl[0,k,l,1]*grad(u[1])[l]*grad(vu[0])[k] \
            - qijkl[0,k,1,l]*p[l]*grad(vu[0])[k]*p[1] - qijkl[0,k,l,1]*p[l]*grad(vu[0])[k]*p[1] + \
            2*Cijkl[0,k,2,l]*grad(u[2])[l]*grad(vu[0])[k] + 2*Cijkl[0,k,l,2]*grad(u[2])[l]*grad(vu[0])[k] \
            - qijkl[0,k,2,l]*p[l]*grad(vu[0])[k]*p[2] - qijkl[0,k,l,2]*p[l]*grad(vu[0])[k]*p[2])*dx + \
            \
            (2*Cijkl[1,k,0,l]*grad(u[0])[l]*grad(vu[1])[k] + 2*Cijkl[1,k,l,0]*grad(u[0])[l]*grad(vu[1])[k] \
             - qijkl[1,k,0,l]*p[l]*grad(vu[1])[k]*p[0] - qijkl[1,k,l,0]*p[l]*grad(vu[1])[k]*p[0] + \
            2*Cijkl[1,k,1,l]*grad(u[1])[l]*grad(vu[1])[k] + 2*Cijkl[1,k,l,1]*grad(u[1])[l]*grad(vu[1])[k] \
            - qijkl[1,k,1,l]*p[l]*grad(vu[1])[k]*p[1] - qijkl[1,k,l,1]*p[l]*grad(vu[1])[k]*p[1] + \
            2*Cijkl[1,k,2,l]*grad(u[2])[l]*grad(vu[1])[k] + 2*Cijkl[1,k,l,2]*grad(u[2])[l]*grad(vu[1])[k] \
            - qijkl[1,k,2,l]*p[l]*grad(vu[1])[k]*p[2] - qijkl[1,k,l,2]*p[l]*grad(vu[1])[k]*p[2])*dx + \
            \
            (2*Cijkl[2,k,0,l]*grad(u[0])[l]*grad(vu[2])[k] + 2*Cijkl[2,k,l,0]*grad(u[0])[l]*grad(vu[2])[k] \
             - qijkl[2,k,0,l]*p[l]*grad(vu[2])[k]*p[0] - qijkl[2,k,l,0]*p[l]*grad(vu[2])[k]*p[0] + \
            2*Cijkl[2,k,1,l]*grad(u[1])[l]*grad(vu[2])[k] + 2*Cijkl[2,k,l,1]*grad(u[1])[l]*grad(vu[2])[k] \
            - qijkl[2,k,1,l]*p[l]*grad(vu[2])[k]*p[1] - qijkl[2,k,l,1]*p[l]*grad(vu[2])[k]*p[1] + \
            2*Cijkl[2,k,2,l]*grad(u[2])[l]*grad(vu[2])[k] + 2*Cijkl[2,k,l,2]*grad(u[2])[l]*grad(vu[2])[k] \
            - qijkl[2,k,2,l]*p[l]*grad(vu[2])[k]*p[2] - qijkl[2,k,l,2]*p[l]*grad(vu[2])[k]*p[2])*dx + \
            \
            (Gijkl[0,k,0,l]*grad(p[0])[l]*grad(vp[0])[k] + Gijkl[0,k,1,l]*grad(p[1])[l]*grad(vp[0])[k] + Gijkl[0,k,2,l]*grad(p[2])[l]*grad(vp[0])[k])*dx + \
            (Gijkl[1,k,0,l]*grad(p[0])[l]*grad(vp[1])[k] + Gijkl[1,k,1,l]*grad(p[1])[l]*grad(vp[1])[k] + Gijkl[1,k,2,l]*grad(p[2])[l]*grad(vp[1])[k])*dx + \
            (Gijkl[2,k,0,l]*grad(p[0])[l]*grad(vp[2])[k] + Gijkl[2,k,1,l]*grad(p[1])[l]*grad(vp[2])[k] + Gijkl[2,k,2,l]*grad(p[2])[l]*grad(vp[2])[k])*dx + \
            \
            vp[0]*(2*ai[0]*p[0] + 2*aij[0,0]*p[0]*p[0]**2 + 2*aij[0,1]*p[0]*p[1]**2 + 2*aij[0,2]*p[0]*p[2]**2 - \
            0.25*(qijkl[0,i,k,l]*grad(u[k])[l]*p[i] + qijkl[0,i,k,l]*grad(u[l])[k]*p[i] + qijkl[0,i,l,k]*grad(u[k])[l]*p[i] + qijkl[0,i,l,k]*grad(u[l])[k]*p[i]))*dx + \
            vp[1]*(2*ai[1]*p[1] + 2*aij[1,0]*p[1]*p[0]**2 + 2*aij[1,1]*p[1]*p[1]**2 + 2*aij[1,2]*p[1]*p[2]**2 - \
            0.25*(qijkl[1,i,k,l]*grad(u[k])[l]*p[i] + qijkl[1,i,k,l]*grad(u[l])[k]*p[i] + qijkl[1,i,l,k]*grad(u[k])[l]*p[i] + qijkl[1,i,l,k]*grad(u[l])[k]*p[i]))*dx + \
            vp[2]*(2*ai[2]*p[2] + 2*aij[2,0]*p[2]*p[0]**2 + 2*aij[2,1]*p[2]*p[1]**2 + 2*aij[2,2]*p[2]*p[2]**2 - \
            0.25*(qijkl[2,i,k,l]*grad(u[k])[l]*p[i] + qijkl[2,i,k,l]*grad(u[l])[k]*p[i] + qijkl[2,i,l,k]*grad(u[k])[l]*p[i] + qijkl[2,i,l,k]*grad(u[l])[k]*p[i]))*dx 
        return(F)

#    def get_LagrangianUP(self):
#        F = self.Landau + self.Ginzburg + self.Elastic + self.Electrostriction
#        return(F)

    def get_LagrangianrUP(self):
        u = self.displacement
        p = self.polarization
        r = self.rotation
        F = ai[0]*p[0]**2 + ai[1]*p[1]**2 + ai[2]*p[2]**2 + \
            0.5*aij[0,0]*p[0]**2*p[0]**2 + 0.5*aij[0,1]*p[0]**2*p[1]**2 + 0.5*aij[0,2]*p[0]**2*p[2]**2 + \
            0.5*aij[1,0]*p[1]**2*p[0]**2 + 0.5*aij[1,1]*p[1]**2*p[1]**2 + 0.5*aij[1,2]*p[1]**2*p[2]**2 + \
            0.5*aij[2,0]*p[2]**2*p[0]**2 + 0.5*aij[2,1]*p[2]**2*p[1]**2 + 0.5*aij[2,2]*p[2]**2*p[2]**2 + \
            0.5*Gijkl[i,j,k,l]*p[i].dx(j)*p[k].dx(l) + \
            0.125*Cijkl[i,j,k,l]*u[i].dx(j)*u[k].dx(l)*pixel**2 + \
            0.125*Cijkl[i,j,k,l]*u[i].dx(j)*u[l].dx(k)*pixel**2 + \
            0.125*Cijkl[i,j,k,l]*u[j].dx(i)*u[k].dx(l)*pixel**2 + \
            0.125*Cijkl[i,j,k,l]*u[j].dx(i)*u[l].dx(k)*pixel**2 - \
            0.25*qijkl[i,j,k,l]*u[i].dx(j)*p[k]*p[l]*pixel - 0.25*qijkl[i,j,k,l]*u[j].dx(i)*p[k]*p[l]*pixel + \
            0.25*fijkl[i,j,k,l]*u[i].dx(j)*p[k].dx(l)*pixel + 0.25*fijkl[i,j,k,l]*u[j].dx(i)*p[k].dx(l)*pixel - \
            p[i]*E[i] - 0.5*p[i]*Ed[i]
        return(F)

    def get_LagrangianUP(self):
        u = self.displacement
        p = self.polarization
        r = self.rotation
        F = ai[0]*p[0]**2 + ai[1]*p[1]**2 + ai[2]*p[2]**2 + \
            0.5*aij[0,0]*p[0]**2*p[0]**2 + 0.5*aij[0,1]*p[0]**2*p[1]**2 + 0.5*aij[0,2]*p[0]**2*p[2]**2 + \
            0.5*aij[1,0]*p[1]**2*p[0]**2 + 0.5*aij[1,1]*p[1]**2*p[1]**2 + 0.5*aij[1,2]*p[1]**2*p[2]**2 + \
            0.5*aij[2,0]*p[2]**2*p[0]**2 + 0.5*aij[2,1]*p[2]**2*p[1]**2 + 0.5*aij[2,2]*p[2]**2*p[2]**2 + \
            0.5*Gijkl[i,j,k,l]*p[i].dx(j)*p[k].dx(l) + \
            0.125*Cijkl[i,j,k,l]*u[i].dx(j)*u[k].dx(l) + \
            0.125*Cijkl[i,j,k,l]*u[i].dx(j)*u[l].dx(k) + \
            0.125*Cijkl[i,j,k,l]*u[j].dx(i)*u[k].dx(l) + \
            0.125*Cijkl[i,j,k,l]*u[j].dx(i)*u[l].dx(k) - \
            0.25*qijkl[i,j,k,l]*u[i].dx(j)*p[k]*p[l] - 0.25*qijkl[i,j,k,l]*u[j].dx(i)*p[k]*p[l] + \
            0.25*fijkl[i,j,k,l]*u[i].dx(j)*p[k].dx(l) + 0.25*fijkl[i,j,k,l]*u[j].dx(i)*p[k].dx(l) - \
            p[i]*E[i] - 0.5*p[i]*Ed[i]
            
        return(F)

def save_sparse_matrix(m,filename):
    thefile = open(filename, 'w')
    nonZeros = np.array(m.nonzero())
    for entry in range(nonZeros.shape[1]):
        irow = nonZeros[0, entry]
        icol = nonZeros[1, entry]
        thefile.write("%s\t%s\t%s\n" % (irow, icol, m[irow, icol]))

def save_sparse_matrix_rows(m,rowslist):
    thefile = open("stiffness.dat", 'w')
    nonZeros = np.array(m.nonzero())
    irow_tmp = -1
    for entry in range(nonZeros.shape[1]):
        irow = nonZeros[0, entry]
        icol = nonZeros[1, entry]
        if irow  in rowslist:
            if irow != irow_tmp:
                print("writing row: "+str(irow))
                irow_tmp = irow
            thefile.write("%s\t%s\t%s\n" % (irow, icol, m[irow, icol]))

def NewtonInfo(jter, eps):
    if jter == 1:
        wtype = 'w'
    else:
        wtype = 'a'
    thefile = open("newton.out", wtype)
    thefile.write("{}\t{:4d}:\t{:.4E}\n".format('Newton', jter, Decimal(eps)))

def NewtonLandauSolver(H=None, dF=None, bcs=[], up0=None, V=None, mix=1.0, tol=1.0E-15, maxiter=10):
    dup = Function(V)
    up_tmp = Function(V)
    u0, p0 = split(up0)
    eps = 1.0
    jter = 0
    vtkfile_u_tmp = File('./FenicsOutputs/tmp/u_iter.pvd')
    vtkfile_p_tmp = File('./FenicsOutputs/tmp/p_iter.pvd')
    vtkfile_u_tmp << (u0, float(jter))
    vtkfile_p_tmp << (p0, float(jter))
    while eps > tol and jter < maxiter:
        jter += 1
        K, b = assemble_system(H, dF, bcs)
    
        solve(K, dup.vector(), b)
    
    #    eps = norm(dup.vector().get_local(), 'linf')
        eps = np.linalg.norm(dup.vector().get_local(), ord=np.Inf)
    
        if MPI.rank(comm) == 0:
            NewtonInfo(jter,eps)
            print("Newton "+str(jter)+":", eps)
    #    up_tmp.assign(up0)
    #    u_tmp.vector().axpy(-mix, dup.vector())
        up_tmp.vector()[:] = up0.vector() - mix*dup.vector()
        up0.assign(up_tmp)
    
        u, p = up_tmp.split()
        vtkfile_u_tmp << (u, float(jter))
        vtkfile_p_tmp << (p, float(jter))

def fft3(f, k, mesh):
    k=as_vector(k)
    r = SpatialCoordinate(mesh)
    return(assemble(f[0]*cos(k[i]*r[i])*dx), assemble(-1*f[0]*sin(k[i]*r[i])*dx))
