#!/usr/bin/env python
import os
import sys
import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.linalg import eigsh

m_O = 15.999; m_Fe = 55.845; m_Bi = 208.98; m_std = 1.6606E-27
m_u = 8*(m_Fe + m_Bi + 3*m_O)*m_std
m_P = 8*m_Bi*m_std
volumeBFO = (8.0E-10)**3

sp_mat_file = "tiltedM.dat"
f = open(sp_mat_file,'r')
sp_mat = []
for line_tmp in f.readlines():
    row, col, value = line_tmp.split()
    sp_mat.append([int(row), int(col), float(value)])
sp_mat = np.array(sp_mat)

row = sp_mat[:,0]
col = sp_mat[:,1]
value = sp_mat[:,2]
dim = row[-1]+1
halfdim = 175860

def i2mass(iu):
    return(((iu//halfdim)*m_u + (1-iu//halfdim)*m_P)**(-0.5))

for i in range(len(value)):
    value[i] = value[i]*i2mass(row[i])*i2mass(col[i])*volumeBFO*1.0E20*1.0E-24

sp_mat = csr_matrix((value, (row, col)), shape=(dim, dim))
lm_val, lm_vec = eigsh(sp_mat, k=10, which='LM')

omega2top = lm_val.real.max()
omega2 = 0.001
num_eigen = 0
count = 0
u0 = 0.0
vals = []
vecs = []
while(omega2 < omega2top and num_eigen < 1000):
    vals_tmp, vecs_tmp = eigsh(sp_mat, k=1000, sigma=omega2, which='LM', maxiter=10000, tol=1.0E-24)
    eigenval = np.sqrt(np.abs(vals_tmp))
    for u,v in zip(eigenval,vecs_tmp.transpose()):
        if u > u0:
            vals.append(u)
            vecs.append(v)

    u0 = eigenval.real.max()
    omega2 = vals_tmp.real.max()
    num_eigen = len(vals)
    count += 1
    print('slice:', count, "omega2 omega2top", omega2, omega2top, "num_eigen", num_eigen)

vals = np.array(vals)
vecs = np.array(vecs)
np.savetxt('eigenval.dat', vals)
np.savetxt('eigenvec.dat', vecs)
