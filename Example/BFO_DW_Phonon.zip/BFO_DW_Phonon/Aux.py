#!/usr/bin/env python
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import BoundaryNorm
from matplotlib.ticker import MaxNLocator
from mpl_toolkits.axes_grid1 import make_axes_locatable, axes_size
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.colors import ListedColormap

def ParseEigen(line):
    if len(line.split()) == 1:
        line_tmp = float(line.split()[0])
    else:
        line_tmp = [float(x) for x in line.split()]
    return(line_tmp)

def colorbar(mappable, ax):
    fig = ax.figure
    divider = make_axes_locatable(ax)
    cax = divider.append_axes("right", size="5%", pad=0.05)
    cbar = fig.colorbar(mappable, cax=cax, format='%.2e')
    cbar.ax.get_yaxis().set_ticks([])
    cbar.ax.set_ylabel('Phonon of $P_2$ weight [arb. u.]')
    return cbar

def SortVec(ValVec, MeshMap, Lx, Lz):
    Pi = {'1':np.zeros((Lz,1,Lx)), '2':np.zeros((Lz,1,Lx)), '3':np.zeros((Lz,1,Lx)), 'w':ValVec[0]}
    ui = {'1':np.zeros((Lz,1,Lx)), '2':np.zeros((Lz,1,Lx)), '3':np.zeros((Lz,1,Lx)), 'w':ValVec[0]}

    for j, m in enumerate(MeshMap):
        if m[0]=='P':
            Pi[m[1]][m[4]-1, m[3]-1, m[2]-1] = ValVec[1][j]
        if m[0]=='u':
            ui[m[1]][m[4]-1, m[3]-1, m[2]-1] = ValVec[1][j]
    return([ui, Pi])

def RenderSpectrum(w, phonon, dim, sigma, Lx, Lz):
    spectrum_w = np.zeros((Lz//2-1,Lx//2-1))
    for iphonon in range(dim):
        spectrum_w += np.abs((phonon[iphonon]['data']**2/(w-phonon[iphonon]['w']-complex(0, sigma))).imag[0:Lz//2-1,0:Lx//2-1])
    return(spectrum_w)

def LossSpectrum(w, phonon, dim, sigma, Lx, Lz, radius):
    eneloss_w = np.zeros(Lx)
    for x0 in range(0,Lx):
        for iphonon in range(dim):
            Efield = np.zeros((Lz,Lx))
            Efield[:,Lx//2-radius:Lx//2+radius] = 1.0
            tip = np.roll(Efield,-Lx//2+1+x0)
            tip[:,Lx-1] = 0.0
            tip[:,0] = 0.0
            tip[Lz-1,:] = 0.0
            ep = np.sum(phonon[iphonon]['3']*tip)
            eneloss_w[x0] += w**2*sigma*ep**2/((w**2-phonon[iphonon]['w']**2)**2+w**2*sigma**2)
    return(eneloss_w)

def LandauFFT(phonon, Lx, Lz, xyz):
    fft = np.fft.fft2(phonon[xyz][:-1,0,:-1])[0:Lz//2, Lx:Lx//2:-1]
    return({'data':fft, 'w':phonon['w']})


